import Reducer from "./contactreducer";
import { combineReducers } from "redux";


const combinereducer =combineReducers({
Reducer
})

export default combinereducer;